package hash

import (
	"fmt"
	"log"
	"testing"
)

func TestHashUrl(t *testing.T)  {
	fmt.Println(HashUrl("gato"))
	log.Println("Finished")
}
